var focus0=0,focus1=0,focus2=0,focusWhere=0;
var json0=0,json1=0,json2=0,json3=0;
/*
focusWhere:焦点位置  0 左边导航栏 1 顶部导航栏 2 内容区域
* */
function keyLeft() {
    if(focusWhere==0){

    }else if(focusWhere==1){
        focusWhere=0;
        $(".gameMatchCont0_left > div").removeClass("homePageCont2_vs1_focus homePageCont2_vs2_focus");
    }else if(focusWhere==2){
        focusWhere=1;
    }
}
function keyUp(){
    if(focusWhere==0){
        if(focus0>0){
            focus0--
        }
        reset_navLeftStyle();
    }
}
function keyRight(){

}
function keyDown(){
    if(focusWhere==0){
        if(focus0<4){
            focus0++;
        }
        reset_navLeftStyle();
    }
}
function keySelect() {

}
function keyBack() {
    exit();
}
function reset_navLeftStyle() {
    $(".gameMatchNavBtn").removeClass("gameMatchNavBtnFocus") ;
    $("#gameMatchNav").children().eq(focus0).addClass("gameMatchNavBtnFocus");
    $(".gameMatchCont").hide();
    $(".gameMatchCont").eq(focus0).show();
}
/*gameMatchCont0*/
function reset_gameMatchCont0_left_Style() {
    $(".gameMatchCont0_left > div").removeClass("homePageCont2_vs1_focus homePageCont2_vs2_focus");
    var objCla = getElementClass($(".gameMatchCont0_left > div").eq(focus1),0);
    if(objCla == "homePageCont2_vs1"){
        $(".gameMatchCont0_left > div").eq(focus1).addClass("homePageCont2_vs1_focus");
    }else {
        $(".gameMatchCont0_left > div").eq(focus1).addClass("homePageCont2_vs2_focus");
    }
}
function reset_gameMatchCont0_right_Style() {
    $(".gameMatchCont0_right_d").removeClass("gameMatchCont0_right_dFocus");
    $(".gameMatchCont0_right > div").eq(focus2).addClass("gameMatchCont0_right_dFocus")
}
/*gameMatchCont1*/

/*gameMatchCont2*/
/*gameMatchCont3*/
