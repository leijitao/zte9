var focus = 0,videoNum = 13;
resetContStyle();
function keyLeft() {
    if(focus>0){
        focus--;
    }
    resetContStyle();
    rollAnimate(4,10,focus,200,$(".allEventContAll"))
}
function keyUp(){
    if (focus > 0 && focus < 5){
        focus = 0;
    }else if( focus > 4){
        focus -= 5;
    }
    resetContStyle();
    rollAnimate(4,10,focus,200,$(".allEventContAll"))
}
function keyRight(){
    if(focus < videoNum - 1){
        focus ++;
    }

    resetContStyle();
    rollAnimate(4,10,focus,200,$(".allEventContAll"))
}
function keyDown(){
    if( focus < videoNum - 5){
        focus += 5;
    }else if(focus > videoNum - 1 - 5 && focus < videoNum - 1){
        focus = videoNum - 1;
    }
    resetContStyle();
    rollAnimate(4,10,focus,200,$(".allEventContAll"));
}
function keySelect() {

}
function keyBack() {
    exit();
}

function resetContStyle() {
    $(".gameClassContent_d_iFocus").hide();
    $(".allEventContAll").children().eq(focus).children(".gameClassContent_d_iFocus").show();
}


function get_allEvents_VideosInfo() {
    $.ajax({
        type:"GET",
        dataType:"json",
        url:"http://"+ip+"/recommend/special/"+ pageUrl +"/list",
        success:function(msg){
            console.log("getNavInfo success"+JSON.stringify(msg));

        },
        error:function (msg) {
            console.log("getNavInfo error:"+msg);
        }
    })
}
