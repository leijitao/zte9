var focus=0,pageType=0,focusArea=1,videoData,videoNum;
var pageUrl;
getUrlParameter("id",pageUrl);
resetBox2Style();
if(pageType==0){
    $(".videoTopicsContBox").show();
    $(".videoTopicsContBox2").hide();
    $(".videoTopicsContBox_iconUp").hide();
    $(".videoTopicsContBox_iconDown").hide();
}else{
    $(".videoTopicsContBox").hide();
    $(".videoTopicsContBox2").show();
    $(".videoTopicsContBox_iconUp").show();
    $(".videoTopicsContBox_iconDown").show();
}
/*pageType:
 1: 当前页面样式为videoTopicsContBox
 2: 当前页面样式为videoTopicsContBox2
 focusArea:
 0 当前焦点在小窗口上
 1 焦点在选集区域
 videoIndex:
 当前播放第几个视频，从0开始
 videoNum:
 总集数 从1开始
*/
function keyLeft() {
    if(pageType==0 && focusArea==1){
        focusArea=0;
        resetBoxStyle();
        rollAnimate(4.69,7,focus,200,$(".videoTopicsContBox > div"));
    }else if(pageType==1 && focusArea==1){
        if(focus==0 || focus % 4==0){
            focusArea=0;
        }else {
            focus--;
        }
        resetBox2Style();
        rollAnimate(3.96,24,focus,200,$(".videoTopicsContBox2 > div"));
    }
}
function keyUp(){
    if(pageType==0 && focusArea==1){
        if(focus>0){
            focus--;
        }
        resetBoxStyle();
        rollAnimate(4.69,7,focus,200,$(".videoTopicsContBox > div"));
    }else if(pageType==1 && focusArea==1){
        if(focus>3){
            focus-=4;
        }else {
            focus=0;
        }
        resetBox2Style();
        rollAnimate(3.96,24,focus,200,$(".videoTopicsContBox2 > div"))
    }
}
function keyRight(){
    if(pageType==0){
        if(focusArea==0){
            focusArea=1;
        }
        resetBoxStyle();
        rollAnimate(4.69,7,focus,200,$(".videoTopicsContBox > div"));
    }else if(pageType==1){
        if(focusArea==0){
            focusArea=1;
        }else if(focusArea==1 && focus < videoNum-1){
            focus++;
        }
        resetBox2Style();
        rollAnimate(3.96,24,focus,200,$(".videoTopicsContBox2 > div"))
    }
}
function keyDown(){
    if(pageType==0 && focusArea==1){
        if(focus < videoNum-1){
            focus++;
        }
        resetBoxStyle();
        rollAnimate(4.69,7,focus,200,$(".videoTopicsContBox > div"));
    }else if(pageType==1 && focusArea==1){
        if(focus < videoNum-4){
            focus+=4;
        }else if(focus > videoNum-5 && focus < videoNum-1){
            focus=videoNum;
        }
        resetBox2Style();
        rollAnimate(3.96,24,focus,200,$(".videoTopicsContBox2 > div"))
    }
}
function keySelect() {
    if(focusArea==0){
        windowStopPlayVideo();
        playVideoList(videoData);
    }
}
function keyBack() {
    exit();
}

function resetBoxStyle() {
    if(focusArea==0){
        $(".videoTopicsCont_videoFocus").show();
        $(".videoTopicsContBox_d").removeClass("videoTopicsContBox_dFocus");
    }else if(focusArea==1){
        $(".videoTopicsCont_videoFocus").hide();
        $(".videoTopicsContBox_d").removeClass("videoTopicsContBox_dFocus");
        $(".videoTopicsContBox > div").children().eq(focus).addClass("videoTopicsContBox_dFocus");
    }
}
function resetBox2Style() {
    if(focusArea==0){
        $(".videoTopicsCont_videoFocus").show();
        $(".videoTopicsContBox2_d").removeClass("videoTopicsContBox2_dFocus");
    }else if(focusArea==1){
        $(".videoTopicsCont_videoFocus").hide();
        $(".videoTopicsContBox2_d").removeClass("videoTopicsContBox2_dFocus");
        $(".videoTopicsContBox2 > div").children().eq(focus).addClass("videoTopicsContBox2_dFocus");
    }
}
window.onload=function(){
    get_videoTopics_VideosInfo();
}
function get_videoTopics_VideosInfo() {
    $.ajax({
        type:"GET",
        dataType:"json",
        url:"http://"+ip+"/media/special/"+ 1407 +"/list",
        success:function(msg){
            console.log("get_videoTopics_VideosInfo success"+JSON.stringify(msg));
            videoNum = msg.length;
            videoData=msg;
            console.log(videoNum);
            for(var x in msg){
                var lis_nav= '<div class="videoTopicsContBox_d"><img class="videoTopicsContBox_d_icon" src="images/videoTopices/playvideo_icon.png" alt=""><img class="videoTopicsContBox_d_lable" src="images/videoTopices/lable.png" alt=""><div><p>'
                    +msg[x].musicName+'</p> </div> </div>';
                $(".videoTopicsContBox_big").append(lis_nav);
            }
            for(var i=0;i<videoNum;i++){
                if($(".videoTopicsContBox_d > div").children().eq(i).width()>=280){
                    var innerhtml=$(".videoTopicsContBox_d > div").children().eq(x).html();
                    $(".videoTopicsContBox_d > div").children().eq(i).empty();
                    var ele="<marquee>"+innerhtml+"</marquee>";
                    $(".videoTopicsContBox_d > div").children().eq(i).append(ele);
                }
            }
            resetBoxStyle(focus);
            playVideo(focus);
        },
        error:function (msg) {
            console.log("getVideosInfo error:"+JSON.stringify(msg));
        }
    })
}
var x,y,width,height,contentId,typeCode,type,serviceId;
if(screen.width==1280){
    x=63;
    y=237;
    width=739;
    height=416;
}else if(screen.width==1920){
    x=94;
    y=355;
    width=1330;
    height=624;
}
function playVideo(i) {
    var playList = {
        "x": x,
        "y": y,
        "width": width,
        "height": height,
        "typeCode": 123,
        "contentId": videoData[i].contentId,
        "serviceId": videoData[i].serviceId,
        "checkAutho": 0
        //0表示播放几十秒后检查是否是会员，如果不是则跳订购，1表示不检查
    };
    windowPlayVideo(playList);
}
