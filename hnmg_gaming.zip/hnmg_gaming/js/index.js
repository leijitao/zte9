function fun() {
    for (var i=0;i<5;i++){
        if($(".homePageCont1_title").children().eq(i).children().eq(0).width()>=260){
            var innerhtml=$(".homePageCont1_title").children().eq(i).children().eq(0).html();
            $(".homePageCont1_title").children().eq(i).empty();
            var ele="<marquee>"+innerhtml+"</marquee>";
            $(".homePageCont1_title").children().eq(i).append(ele);
        }else {
            $(".homePageCont1_title").children().eq(i).children().eq(0).width("100%");
        }
    }
}
fun();
var focusArea=1,navBtnFocus=0,contentBtnFocus=0;
/*
focusArea 判断焦点区域
1：导航栏
2：推荐位区域

navBtnFocus 判断当前导航栏焦点位置，精选 0 → 订购 9

contentBtnFocus 判断当前推荐位栏焦点位置，下标从0开始
*/
function navResteStyle() {
    for(var i=0;i<8;i++){
        if ($("#NavBar").children().eq(i).html().length==2){
            $("#NavBar").children().eq(i).addClass("NavBtn_letrer2")
        }else {
            $("#NavBar").children().eq(i).addClass("NavBtn_letrer4")
        }
    }
    $("#NavBar").children().eq(0).addClass("navBtnLeft");
}
navResteStyle();
function navRemoveStyle() {
    $("#NavBar").children().eq(0).removeClass("navBtnLeft");
    $("#NavBar").children().eq(7).removeClass("navBtnRight");
    for (var i=1;i<7;i++){
        $("#NavBar").children().eq(i).removeClass("navBtnMid");
    }
    $("#othBtn").children().hide();
}
function navMoveFocusStyle() {
    navRemoveStyle();
    if(navBtnFocus == 0){
        $(".navBtn1").addClass("navBtnLeft")
    }else if(navBtnFocus > 0 && navBtnFocus < 7){
        $(".navBtn" + (navBtnFocus+1)).addClass("navBtnMid")
    }else if(navBtnFocus == 7){
        $(".navBtn8").addClass("navBtnRight")
    }else if(navBtnFocus > 7 && navBtnFocus < 10){
        $("#othBtn").children().eq(navBtnFocus-8).show();
    }
}
function resetFocus_left(fun) {
    if (contentBtnFocus > 0 && contentBtnFocus < 3 ||
        contentBtnFocus > 3 && contentBtnFocus < 9 ||
        contentBtnFocus > 9 && contentBtnFocus < 13){
        contentBtnFocus--;
    }
    fun();
}
function resetFocus_up(fun1,fun2) {
    if (contentBtnFocus >= 0 && contentBtnFocus < 3){
        contentBtnFocus=0;
        focusArea=1;
        fun1();
    }else if(contentBtnFocus == 9){
        contentBtnFocus=3;
        fun2();
    }else if(contentBtnFocus == 10){
        contentBtnFocus=5;
        fun2();
    }else if(contentBtnFocus == 11){
        contentBtnFocus=6;
        fun2();
    }else if(contentBtnFocus == 12){
        contentBtnFocus=8;
        fun2();
    }else if(contentBtnFocus > 2 && contentBtnFocus < 9){
        contentBtnFocus = Math.ceil(contentBtnFocus/2)-2;
        fun2();
    }
}
function resetFocus_right(fun) {
    if (contentBtnFocus >= 0 && contentBtnFocus < 2 ||
        contentBtnFocus > 2 && contentBtnFocus < 8 ||
        contentBtnFocus > 8 && contentBtnFocus < 12){
        contentBtnFocus++;
    }
    fun();
}
function resetFocus_down(fun) {
    if(contentBtnFocus>=0 && contentBtnFocus<3){
        contentBtnFocus=contentBtnFocus*2+3;
    }else if(contentBtnFocus == 3 || contentBtnFocus == 4){
        contentBtnFocus=9;
    }else if(contentBtnFocus == 5){
        contentBtnFocus=10;
    }else if(contentBtnFocus == 6 || contentBtnFocus == 7){
        contentBtnFocus=11;
    }else if(contentBtnFocus == 8){
        contentBtnFocus=12;
    }
    fun();
}
function keyLeft() {
    if(focusArea==1){
        if(navBtnFocus>0){
            navBtnFocus--;
            if(navBtnFocus<8){
                $("#homePageCont").children().hide();
                $("#homePageCont").children().eq(navBtnFocus).show();
            }
        }
        navMoveFocusStyle();
    }else if(focusArea==2){
        if(navBtnFocus==0){
            if(contentBtnFocus>8){
                contentBtnFocus=4;
            }else if(contentBtnFocus==4){
                contentBtnFocus=0
            }else if(contentBtnFocus>5 && contentBtnFocus <9){
                contentBtnFocus--;
            }
            homePageCont1_ResetStyle();
        }else if(navBtnFocus==1){
            if(contentBtnFocus==3){
                contentBtnFocus=0;
            }else if(contentBtnFocus==4){
                contentBtnFocus=3;
            }else if(contentBtnFocus>5){
                contentBtnFocus--;
            }
            homePageCont2_ResetStyle();
        }else if(navBtnFocus==2){
            if(contentBtnFocus>0){
                contentBtnFocus=0;
            }
            homePageCont3_ResetStyle();
        }else if(navBtnFocus==3){
            resetFocus_left(homePageCont4_ResetStyle);
        }else if(navBtnFocus==4){
            resetFocus_left(homePageCont5_ResetStyle);
        }else if(navBtnFocus==5){
            resetFocus_left(homePageCont6_ResetStyle);
        }else if(navBtnFocus==6){
            resetFocus_left(homePageCont7_ResetStyle);
        }else if(navBtnFocus==7){
            resetFocus_left(homePageCont8_ResetStyle);
        }
    }
}
function keyUp() {
    if(focusArea==1){
        if(navBtnFocus<7){
            navBtnFocus=8;
        }else if(navBtnFocus==7){
            navBtnFocus=9;
        }
        navMoveFocusStyle();
    }else if(focusArea==2){
        if(navBtnFocus==0){
            if(contentBtnFocus > 9){
                contentBtnFocus--;
                homePageCont1_ResetStyle();
            }else if(contentBtnFocus==8){
                contentBtnFocus=13;
                homePageCont1_ResetStyle();
            }else if(contentBtnFocus==7 || contentBtnFocus==6){
                contentBtnFocus=4;
                homePageCont1_ResetStyle();
            }else if(contentBtnFocus==5){
                contentBtnFocus=3;
                homePageCont1_ResetStyle();
            }else if(contentBtnFocus>0 && contentBtnFocus<4){
                contentBtnFocus--;
                homePageCont1_ResetStyle();
            }else if(contentBtnFocus==0 || contentBtnFocus==4|| contentBtnFocus==9){
                homePageCont1_RemoveStyle();
                contentBtnFocus=0;
                focusArea=1;
            }
        }else if(navBtnFocus==1){
            if(contentBtnFocus > 0 && contentBtnFocus < 3){
                contentBtnFocus--;
                homePageCont2_ResetStyle();
            }else if(contentBtnFocus > 4 && contentBtnFocus < 8){
                contentBtnFocus=2;
                homePageCont2_ResetStyle();
            }else if(contentBtnFocus == 8 || contentBtnFocus == 9){
                contentBtnFocus=3;
                homePageCont2_ResetStyle();
            }else if(contentBtnFocus == 10){
                contentBtnFocus=4;
                homePageCont2_ResetStyle();
            }else if(contentBtnFocus == 0 || contentBtnFocus == 3 || contentBtnFocus == 4){
                homePageCont2_RemoveStyle();
                contentBtnFocus=0;
                focusArea=1;
            }
        }else if(navBtnFocus==2){
            if(contentBtnFocus<2){
                homePageCont3_RemoveStyle();
                contentBtnFocus=0;
                focusArea=1;
            }else {
                contentBtnFocus--;
                homePageCont3_ResetStyle()
            }
        }else if(navBtnFocus==3){
            resetFocus_up(homePageCont4_RemoveStyle,homePageCont4_ResetStyle)
        }else if(navBtnFocus==4){
            resetFocus_up(homePageCont5_RemoveStyle,homePageCont5_ResetStyle)
        }else if(navBtnFocus==5){
            resetFocus_up(homePageCont6_RemoveStyle,homePageCont6_ResetStyle)
        }else if(navBtnFocus==6){
            resetFocus_up(homePageCont7_RemoveStyle,homePageCont7_ResetStyle)
        }else if(navBtnFocus==7){
            resetFocus_up(homePageCont8_RemoveStyle,homePageCont8_ResetStyle)
        }
    }
    console.log("focusArea:"+focusArea+",navBtnFocus:"+navBtnFocus);
}
function keyRight() {
    if(focusArea==1){
        if(navBtnFocus<9){
            navBtnFocus++;
            if(navBtnFocus<8){
                $("#homePageCont").children().hide();
                $("#homePageCont").children().eq(navBtnFocus).show();
            }
        }
        navMoveFocusStyle();
    }else if(focusArea==2){
        if(navBtnFocus==0){
            if(contentBtnFocus<4){
                contentBtnFocus=4;
            }else if(contentBtnFocus==4){
                contentBtnFocus=9;
            }else if(contentBtnFocus>4 && contentBtnFocus <8){
                contentBtnFocus++;
            }
            homePageCont1_ResetStyle();
        }else if(navBtnFocus==1){
            if(contentBtnFocus < 3){
                contentBtnFocus=3;
            }else if (contentBtnFocus == 3 || contentBtnFocus > 4 && contentBtnFocus<10){
                contentBtnFocus++;
            }
            homePageCont2_ResetStyle();
        }else if(navBtnFocus==2){
            if(contentBtnFocus==0){
                contentBtnFocus=1;
            }
            homePageCont3_ResetStyle();
        }else if(navBtnFocus==3){
            resetFocus_right(homePageCont4_ResetStyle);
        }else if(navBtnFocus==4){
            resetFocus_right(homePageCont5_ResetStyle);
        }else if(navBtnFocus==5){
            resetFocus_right(homePageCont6_ResetStyle);
        }else if(navBtnFocus==6){
            resetFocus_right(homePageCont7_ResetStyle);
        }else if(navBtnFocus==7){
            resetFocus_right(homePageCont8_ResetStyle);
        }
    }
}
function keyDown() {
    if(focusArea==1){
        if(navBtnFocus==8){
            navBtnFocus=6;
            navMoveFocusStyle();
        }else if(navBtnFocus==9){
            navBtnFocus=7;
            navMoveFocusStyle();
        }else if(navBtnFocus<8){
            focusArea=2;
            if(navBtnFocus==0){
                homePageCont1_ResetStyle();
            }else if(navBtnFocus==1){
                homePageCont2_ResetStyle();
            }else if(navBtnFocus==2){
                homePageCont3_ResetStyle();
            }else if(navBtnFocus==3){
                homePageCont4_ResetStyle();
            }else if(navBtnFocus==4){
                homePageCont5_ResetStyle();
            }else if(navBtnFocus==5){
                homePageCont6_ResetStyle();
            }else if(navBtnFocus==6){
                homePageCont7_ResetStyle();
            }else if(navBtnFocus==7){
                homePageCont8_ResetStyle();
            }

        }
    }else if(focusArea==2){
        if(navBtnFocus==0){
            if(contentBtnFocus > 8 && contentBtnFocus < 13){
                contentBtnFocus++;
            }else if(contentBtnFocus==13){
                contentBtnFocus=8;
            }else if(contentBtnFocus==4){
                contentBtnFocus=6
            }else if(contentBtnFocus==3){
                contentBtnFocus=5
            }else if(contentBtnFocus>=0 && contentBtnFocus<3){
                contentBtnFocus++
            }
            homePageCont1_ResetStyle();
        }else if(navBtnFocus==1){
            if(contentBtnFocus<2){
                contentBtnFocus++;
            }else if(contentBtnFocus==2){
                contentBtnFocus=5;
            }else if(contentBtnFocus==3){
                contentBtnFocus=8;
            }else if(contentBtnFocus==4){
                contentBtnFocus=10;
            }
            homePageCont2_ResetStyle();
        }else if(navBtnFocus==2){
            if(contentBtnFocus>0 && contentBtnFocus<4){
                contentBtnFocus++;
            }
            homePageCont3_ResetStyle();
        }else if(navBtnFocus==3){
            resetFocus_down(homePageCont4_ResetStyle);
        }else if(navBtnFocus==4){
            resetFocus_down(homePageCont5_ResetStyle);
        }else if(navBtnFocus==5){
            resetFocus_down(homePageCont6_ResetStyle);
        }else if(navBtnFocus==6){
            resetFocus_down(homePageCont7_ResetStyle);
        }else if(navBtnFocus==7){
            resetFocus_down(homePageCont8_ResetStyle);
        }
    }
    console.log("focusArea:"+focusArea+",navBtnFocus:"+navBtnFocus+",contentBtnFocus:"+contentBtnFocus);
}
function keySelect() {
    if(focusArea==2){
        if(navBtnFocus==3){
            newURl("http://"+ webPageIp + "/gameClass.html?id=1353");
        }else if(navBtnFocus==0){
            newURl("http://"+ webPageIp + "/videoTopics.html?id=1401");
        }else if(navBtnFocus==2){
            newURl("http://"+ webPageIp + "/gameMatch.html");
        }else if(navBtnFocus==1) {
            newURl("http://" + webPageIp + "/allEvents.html");
        }else {
            newURl("http://"+ webPageIp + "/gameClass.html?id=1353");
        }
    }
}
function keyBack() {

}
function keyNum_mg() {

}
function keyNum_hc() {

}
function keyDelete() {

}

function homePageCont1_RemoveStyle() {
    for(var i=0;i<4;i++){
        $("#homePageCont1_poster").children().eq(i).removeClass("leftFocus")
    }
    for(var i=5;i<9;i++){
        $("#homePageCont1_poster").children().eq(i).removeClass("bottomFocus")
    }
    $("#homePageCont1_poster").children().eq(4).removeClass("videoFocus");
    $("#homePageCont1_title").children().removeClass("homePageCont1_title_d_focus")
}
function homePageCont1_ResetStyle(){
    homePageCont1_RemoveStyle();
    console.log("00000");
    if(contentBtnFocus < 4){
        $("#homePageCont1_poster").children().eq(contentBtnFocus).addClass("leftFocus");
    }else if(contentBtnFocus==4){
        $("#homePageCont1_poster").children().eq(contentBtnFocus).addClass("videoFocus")
    }else if(contentBtnFocus>4 && contentBtnFocus<9){
        $("#homePageCont1_poster").children().eq(contentBtnFocus).addClass("bottomFocus")
    }else if(contentBtnFocus>8 && contentBtnFocus<14){
        $("#homePageCont1_title").children().eq(contentBtnFocus-9).addClass("homePageCont1_title_d_focus");
    }
}
function homePageCont2_RemoveStyle() {
    $("#homePageCont2_match > div").removeClass("homePageCont2_vs1_focus homePageCont2_vs2_focus");
    $("#homePageCont2_posterBig > div").removeClass("homePageCont2_posterBig_focus");
    $("#homePageCont2_posterSm > div").removeClass("homePageCont2_posterSm_focus");
}
function homePageCont2_ResetStyle() {
    homePageCont2_RemoveStyle();
    if(contentBtnFocus<3){
        var objCla = getElementClass($("#homePageCont2_match > div").eq(contentBtnFocus),0);
        if(objCla == "homePageCont2_vs1"){
            $("#homePageCont2_match > div").eq(contentBtnFocus).addClass("homePageCont2_vs1_focus");
        }else {
            $("#homePageCont2_match > div").eq(contentBtnFocus).addClass("homePageCont2_vs2_focus");
        }
    }else if(contentBtnFocus>4){
        $("#homePageCont2_posterSm > div").eq(contentBtnFocus-5).addClass("homePageCont2_posterSm_focus");
    }else {
        $("#homePageCont2_posterBig > div").eq(contentBtnFocus-3).addClass("homePageCont2_posterBig_focus")
    }
}
function homePageCont3_RemoveStyle() {
    $("#homePageCont3").children().eq(0).removeClass("homePageCont3_videoWindow_focus");
    for (var i=1;i<5;i++){
        $("#homePageCont3").children().eq(i).removeClass("homePageCont3_videoPoster_focus");
    }
}
function homePageCont3_ResetStyle() {
    homePageCont3_RemoveStyle();
    if(contentBtnFocus==0){
        $("#homePageCont3").children().eq(0).addClass("homePageCont3_videoWindow_focus");
    }else {
        $("#homePageCont3").children().eq(contentBtnFocus).addClass("homePageCont3_videoPoster_focus");
    }
}
function homePageCont4_RemoveStyle() {
    $(".homePageCont4_top > div").removeClass("homePageCont4_top_focus");
    $(".homePageCont4_middle > div").removeClass("homePageCont4_middle_focus1");
    $(".homePageCont4_middle > div > div").removeClass("homePageCont4_middle_focus2");
    $(".homePageCont4_bottom > div").removeClass("homePageCont4_bottom_focus");
}
function homePageCont4_ResetStyle() {
    homePageCont4_RemoveStyle();
    if(contentBtnFocus<3){
        $("#homePageCont4 .homePageCont4_top > div").eq(contentBtnFocus).addClass("homePageCont4_top_focus");
    }else if(contentBtnFocus > 2 && contentBtnFocus < 9){
        $("#homePageCont4 .homePageCont4_middle > div").eq(contentBtnFocus-3).addClass("homePageCont4_middle_focus1");
        $("#homePageCont4 .homePageCont4_middle > div").eq(contentBtnFocus-3).children().eq(1).addClass("homePageCont4_middle_focus2");
    }else if(contentBtnFocus > 8 && contentBtnFocus < 13){
        $("#homePageCont4 .homePageCont4_bottom > div").eq(contentBtnFocus-9).addClass("homePageCont4_bottom_focus");
    }
}
function homePageCont5_RemoveStyle() {
    $(".homePageCont5_top > div").removeClass("homePageCont5_top_focus");
    $(".homePageCont5_middle > div").removeClass("homePageCont5_middle_focus1");
    $(".homePageCont5_middle > div > div").removeClass("homePageCont5_middle_focus2");
    $(".homePageCont5_bottom > div").removeClass("homePageCont5_bottom_focus");
}
function homePageCont5_ResetStyle() {
    homePageCont5_RemoveStyle();
    if(contentBtnFocus<3){
        $(".homePageCont5_top > div").eq(contentBtnFocus).addClass("homePageCont5_top_focus");
    }else if(contentBtnFocus > 2 && contentBtnFocus < 9){
        $(".homePageCont5_middle > div").eq(contentBtnFocus-3).addClass("homePageCont5_middle_focus1");
        $(".homePageCont5_middle > div").eq(contentBtnFocus-3).children().eq(1).addClass("homePageCont5_middle_focus2");
    }else if(contentBtnFocus > 8 && contentBtnFocus < 13){
        $(".homePageCont5_bottom > div").eq(contentBtnFocus-9).addClass("homePageCont5_bottom_focus");
    }
}
function homePageCont6_RemoveStyle() {
    $("#homePageCont6 .homePageCont4_top > div").removeClass("homePageCont4_top_focus");
    $("#homePageCont6 .homePageCont4_middle > div").removeClass("homePageCont4_middle_focus1");
    $("#homePageCont6 .homePageCont4_middle > div > div").removeClass("homePageCont4_middle_focus2");
    $("#homePageCont6 .homePageCont4_bottom > div").removeClass("homePageCont4_bottom_focus");
}
function homePageCont6_ResetStyle() {
    homePageCont4_RemoveStyle();
    if(contentBtnFocus<3){
        $("#homePageCont6 .homePageCont4_top > div").eq(contentBtnFocus).addClass("homePageCont4_top_focus");
    }else if(contentBtnFocus > 2 && contentBtnFocus < 9){
        $("#homePageCont6 .homePageCont4_middle > div").eq(contentBtnFocus-3).addClass("homePageCont4_middle_focus1");
        $("#homePageCont6 .homePageCont4_middle > div").eq(contentBtnFocus-3).children().eq(1).addClass("homePageCont4_middle_focus2");
    }else if(contentBtnFocus > 8 && contentBtnFocus < 13){
        $("#homePageCont6 .homePageCont4_bottom > div").eq(contentBtnFocus-9).addClass("homePageCont4_bottom_focus");
    }
}
function homePageCont7_RemoveStyle() {
    $("#homePageCont7 .homePageCont4_top > div").removeClass("homePageCont4_top_focus");
    $("#homePageCont7 .homePageCont4_middle > div").removeClass("homePageCont4_middle_focus1");
    $("#homePageCont7 .homePageCont4_middle > div > div").removeClass("homePageCont4_middle_focus2");
    $("#homePageCont7 .homePageCont4_bottom > div").removeClass("homePageCont4_bottom_focus");
}
function homePageCont7_ResetStyle() {
    homePageCont4_RemoveStyle();
    if(contentBtnFocus<3){
        $("#homePageCont7 .homePageCont4_top > div").eq(contentBtnFocus).addClass("homePageCont4_top_focus");
    }else if(contentBtnFocus > 2 && contentBtnFocus < 9){
        $("#homePageCont7 .homePageCont4_middle > div").eq(contentBtnFocus-3).addClass("homePageCont4_middle_focus1");
        $("#homePageCont7 .homePageCont4_middle > div").eq(contentBtnFocus-3).children().eq(1).addClass("homePageCont4_middle_focus2");
    }else if(contentBtnFocus > 8 && contentBtnFocus < 13){
        $("#homePageCont7 .homePageCont4_bottom > div").eq(contentBtnFocus-9).addClass("homePageCont4_bottom_focus");
    }
}
function homePageCont8_RemoveStyle() {
    $("#homePageCont8 .homePageCont4_top > div").removeClass("homePageCont4_top_focus");
    $("#homePageCont8 .homePageCont4_middle > div").removeClass("homePageCont4_middle_focus1");
    $("#homePageCont8 .homePageCont4_middle > div > div").removeClass("homePageCont4_middle_focus2");
    $("#homePageCont8 .homePageCont4_bottom > div").removeClass("homePageCont4_bottom_focus");
}
function homePageCont8_ResetStyle() {
    homePageCont4_RemoveStyle();
    if(contentBtnFocus<3){
        $("#homePageCont8 .homePageCont4_top > div").eq(contentBtnFocus).addClass("homePageCont4_top_focus");
    }else if(contentBtnFocus > 2 && contentBtnFocus < 9){
        $("#homePageCont8 .homePageCont4_middle > div").eq(contentBtnFocus-3).addClass("homePageCont4_middle_focus1");
        $("#homePageCont8 .homePageCont4_middle > div").eq(contentBtnFocus-3).children().eq(1).addClass("homePageCont4_middle_focus2");
    }else if(contentBtnFocus > 8 && contentBtnFocus < 13){
        $("#homePageCont8 .homePageCont4_bottom > div").eq(contentBtnFocus-9).addClass("homePageCont4_bottom_focus");
    }
}
