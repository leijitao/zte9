var bridge;
// 测试ip
var ip=112+"."+18+"."+251+"."+15+":"+5400+"/scydGaming_api";
var ip_local=112+"."+18+"."+251+"."+15+":"+5400+"/dianjing";
// var ip_local=192+"."+168+"."+0+"."+89+":"+8080+"/dianjing";


//来自于哪个平台 0 中兴  1华为  2烽火
var userId = window.widgetmanager.getParameter('userId');
// var userId = 18349306863;
var deviceId= window.widgetmanager.getParameter('deviceID');
// var deviceId= 123;
console.log('userId:'+userId+'deviceId:'+deviceId);

var videoNum;
var VipResult;
var palyVideoUrl716;

var model_mg;
var versionCode_mg;
var versionName_mg;
var release_mg;
var currentdate;

var click_goback=true;

// 正式ip
// var ip=58+"."+20+"."+27+"."+16+":"+8080+"/hnmgGaming_api";
// var ip_local=58+"."+20+"."+27+"."+16+":"+8080;
// 公网ip
// var ip=115+"."+28+"."+228+"."+74+":"+5522+"/hnmgGaming_api";
// var ip_local=115+"."+28+"."+228+"."+74+":"+5522;

//一级导航样式重置
 reset_fir=function (num){
    $('.title_first').children().hide();
    $('.title_first').children().eq(0).show();
    $('.title_first').children().eq(num+1).show();
}

// //外部推荐位跳转
// setupWebViewJavascriptBridge(function (bridge) {
//     bridge.registerHandler("gameHandler", function (data) {
//         // alert("gameHandler:" + data);
//         data=JSON.parse(data);
//         console.log("data.type1:"+data.type);
//         if(data.type==1){
//             console.log("data.type1");
//             windowStopPlayVideo();
//             window.location.href = data.jumpUrl;
//
//         }else if (data.type==2){
//             console.log("data.type2");
//             windowStopPlayVideo();
//             // J("ztlist.html?recomId=" + data.id);
//             function newURl() {
//                 bridge.callHandler('newURlBridgeHandler', "http://"+ ip_local +"/dianjing/ztlist.html?recomId=" + data.id, function (response) {
//                     console.log("newURlBridgeHandler:" + response);
//                 })
//             }
//             newURl();
//         }else if (data.type==3){
//             console.log("data.type3");
//             windowStopPlayVideo();
//             playVideo({
//                 "musicName":data.musicName,
//                 "playerName":data.playerName,
//                 "typeCode":data.typeCode,
//                 "contentId":data.contentId,
//                 "serviceId":data.serviceId,
//                 "checkAutho":data.checkAutho,//0表示播放几十秒后检查是否是会员，如果不是则跳订购，1表示不检查
//             });
//         }else if (data.type==4){
//             console.log("data.type4");
//             windowStopPlayVideo();
//             installPackageAndLaunch(data.packageName,data.url)
//         }else if (data.type==5){
//             windowStopPlayVideo();
//             function newURl() {
//                 bridge.callHandler('newURlBridgeHandler', "http://"+ ip_local +"/dianjing/ztlist.html?recomId=" + data.id + "recomId=1", function (response) {
//                     console.log("newURlBridgeHandler:" + response);
//                 })
//             }
//             newURl();
//         }
//     })
// })




//获取当前时间 年月日
function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
        + " " + date.getHours() + seperator2 + date.getMinutes()
        + seperator2 + date.getSeconds();
}


//获取播放地址
// function getVideoUrl(contentId) {
//     $.ajax({
//         type:"GET",
//         dataType:"json",
//         // url:"http://"+ip +"/hnmg/hnmgOrderMonthly",
//         url:"http://58.20.27.16:8088/hnmgGaming_pay/hnmg/hnmgOrderMonthly",
//         data:{
//             "contentId":contentId,
//         },
//         success:function(msg){
//
//
//         },
//         error:function (msg) {
//             alert(msg);
//             console.log("order:"+msg);
//
//         }
//     })
// }

// 计费
function charging(packageId,action,merchantId,contentList) {
    $.ajax({
        type: "GET",
        dataType: "json",
        url: "http://112.54.201.200:8082/yst-pvn-prd-api/cp/syncPackageContentRelation",
        data: {
            "packageId": packageId,
            "action": action,
            "merchantId": merchantId,
            "contentList": contentList
        },
        success: function (msg) {
            console.log("charging success" + JSON.stringify(msg));

        },
        error: function (msg) {
            console.log("charging error" + JSON.stringify(msg));
        }
    })
}

/*播放时鉴权
鉴权返回码
0	鉴权成功
320	DB处理异常
340	请求参数为空
350	本地数据校验异常
360	配置项未配置
400	用户未订购产品包
670	运营商处理异常
680	运营商返回TOKEN失效
999	系统异常*/
function authentication(serviceId ,productIds,musicName,method) {
    console.log("userId:"+ userId+",serviceId:"+serviceId+",productIds:"+productIds+",musicName:"+musicName+",method:"+method);
    $.ajax({
        type: "GET",
        dataType: "json",
        url: "http://112.18.251.15:5400/scydGaming_pay/scyd/queryUserInfo",
        data: {
            "custId": userId,
            "contentId": serviceId ,
            "productIds": productIds,
            "musicName":musicName
        },
        success: function (msg) {
            console.log("authentication success" + JSON.stringify(msg));
            if (msg.data.result == 400) {
                //    去订购
                window.location.href = msg.data.cloudPayUrl;
            } else if(msg.data.result == 0){
            //    已订购该包月
                method;
            }else{

            }
        },
        error: function (msg) {
            console.log("authentication error" + JSON.stringify(msg))
        }
    })
}


//   中九 点播，其他，二级节点，推荐位点击数统计
// play	不为空则为点播统计
// other	不为空则为其他统计
// category	不为空则为二级节点统计
// recClick	不为空则为点播数据统计

//一级、二级导航统计

function category_zte(typeCode,pageName){
    $.ajax({
        type:"GET",
        dataType:"json",
        url:"http://"+ ip + "/stat/music/category",
        data:{
            'model':"",
            'version':"",
            'release':"",
            'mac':"",
            'versionCode':"",
            'versionName':"",
            'userId':userId,
            'typeCode':typeCode,
            'pageName':pageName,
        },

        success:function(msg){
            console.log(msg);
            // alert("msg.code:"+msg.code);
        },
        error:function (msg) {
            console.log("statistics_zte:"+msg);
        }
    })
}
//推荐位统计
function recClick_zte(recommId,specialName){
    $.ajax({
        type:"GET",
        dataType:"json",
        url:"http://"+ ip + "/stat/music/recClick",
        data:{
            'model':'',
            'version':'',
            'release':'',
            'mac':'',
            'versionCode':'',
            'versionName':'',
            'userId':userId,
            'recommdId':recommId,
            'pageName':specialName,
        },

        success:function(msg){
            console.log(msg);
            // alert(msg.code);
        },
        error:function (msg) {
            // alert(msg.code);
        }
    })
}
//搜索、订购统计
function other_zte(pageName){
    $.ajax({
        type:"GET",
        dataType:"json",
        url:"http://"+ ip + "/stat/music/other",
        data:{
            'model':'',
            'version':'',
            'release':'',
            'mac':'',
            'versionCode':'',
            'versionName':'',
            'userId':userId,
            'pageName':pageName,
        },

        success:function(msg){
            // alert("msg.codemsg.codemsg.code"+msg.code);
            console.log(msg);

        },
        error:function (msg) {
            console.log("statistics_zte:"+msg);
        }
    })
}

//芒果统计
//1 心跳 operator: 001:湖南电信 002:湖南联通 003:湖南移动

// function statisticsHeart_mg() {
//     $.ajax({
//         type:"GET",
//         dataType:"json",
//         url:"http://"+ ip + "/stat/music/other",
//         data:{
//             'user_id':userId_mg,
//             'mac':userMacAddress_mg,
//             'operator':'002',
//             'sp_code':,
//             'create_time':,
//         },
//
//         success:function(msg){
//             alert("msg.codemsg.codemsg.code"+msg.code);
//             console.log(msg);
//
//         },
//         error:function (msg) {
//             console.log("statistics_mg:"+msg);
//         }
//     })
// }

//2 页面浏览 'event_type':,'button_id ':,'button_name':,'reserve1':,'reserve2':,为空
//3 点击事件
// function statisticsVisitHtml_mg(currentdate,page_id,pagepath,nextpagepath,pagename,special_id,way,offset_name,offset_id,category_id,media_id,key,event_type,button_id,button_name,reserve1,reserve2,offset_group,media_group,channel_id) {
//     getNowFormatDate();
//     $.ajax({
//         type:"GET",
//         dataType:"json",
//         url:"http://119.39.13.147/DataCollection ",
//         data:{
//             'type':'0x07',
//             'user_id':userId_mg,
//             'mac':userMacAddress_mg,
//             'operator':'002',
//             'sp_code':'f1bd6740e96341a290588556fd01b810',
//             'create_time':currentdate,
//             'page_id':page_id,
//             'pagepath':pagepath,
//             'nextpagepath':nextpagepath,
//             'pagename':pagename,
//             'special_id':special_id,
//             'way':way,
//             'offset_name':offset_name,
//             'offset_id':offset_id,
//             'category_id':category_id,
//             'media_id ':media_id,
//             'key':key,
//             'event_type':event_type,
//             'button_id ':button_id,
//             'button_name':button_name,
//             'reserve1':reserve1,
//             'reserve2':reserve2,
//             'offset_group':offset_group,
//             'media_group':media_group,
//             'channel_id':channel_id,
//         },
//
//         success:function(msg){
//             alert("statisticsVisitHtml_mg:"+msg.code);
//             // console.log(msg);
//
//         },
//         error:function (msg) {
//             console.log("statistics_mg:"+msg);
//         }
//     })
// }
//
// statisticsVisitHtml_mg('','','','','','','','','','','','','','','','','','','','');

